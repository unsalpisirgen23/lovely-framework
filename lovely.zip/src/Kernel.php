<?php

namespace Lovely\Framework;

class Kernel{

    public function __construct()
    {
        echo "asdfdf";    
    }

}